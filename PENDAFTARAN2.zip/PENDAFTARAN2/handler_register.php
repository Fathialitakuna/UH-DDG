<?php 
 $nama = $_POST['nama'];
 $email = $_POST['email'];
 $password = $_POST['password'];
 
 $koneksi = new mysqli('localhost', 'root','', 'biodata2');
 if ($koneksi){
     echo "koneksi berhasil";
 }else{
     echo $koneksi->error;
 }
 
 $insert = $koneksi->query("INSERT INTO pengguna
 (nama,email,password)
 values
 ('$nama','$email', '$password')
 ");
 
 if  ($insert){
     echo "insert data berhasil";
 }else{
     echo "gagal insert data";
 }

?>