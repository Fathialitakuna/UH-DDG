<?php


$nama = $_POST['nama'];
$password = $_POST['password'];

$koneksi = new mysqli('localhost', 'root', '', 'biodata2');
if ($koneksi) {
    echo "koneksi berhasil";
} else {
    echo $koneksi->error;
}

$query = "SELECT * FROM pengguna WHERE nama='$nama' AND password='$password'";
$result = $koneksi->query($query);

if ($result->num_rows > 0) {
    // Jika ditemukan, inisialisasi sesi dan arahkan ke halaman beranda atau halaman lainnya.
    $_SESSION['nama'] = $nama;
    header('Location: beranda.php');
} else {
    // Jika tidak ditemukan, beri pesan kesalahan.
    echo "Nama pengguna atau kata sandi salah. Silakan coba lagi.";
}
?>
